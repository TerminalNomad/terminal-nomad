import { motion } from "motion/react";
import { 
  Youtube, 
  Instagram, 
  Twitter, 
  Globe, 
  Video, 
  Heart, 
  Star, 
  ChevronRight, 
  MapPin, 
  ExternalLink,
  Play,
  DollarSign,
  MessageSquare
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";

// Mock Data
const LATEST_VIDEOS = [
  {
    id: 1,
    title: "Skydiving over the Swiss Alps",
    thumbnail: "https://picsum.photos/seed/skydiving1/800/450",
    views: "12K",
    date: "2 days ago"
  },
  {
    id: 2,
    title: "Exploring Hidden Waterfalls in Bali",
    thumbnail: "https://picsum.photos/seed/bali/800/450",
    views: "45K",
    date: "1 week ago"
  },
  {
    id: 3,
    title: "Tandem Jump with a 90-year-old!",
    thumbnail: "https://picsum.photos/seed/skydiving2/800/450",
    views: "89K",
    date: "2 weeks ago"
  }
];

const TRAVELS = [
  {
    id: 1,
    location: "Interlaken, Switzerland",
    image: "https://picsum.photos/seed/switzerland/600/800",
    description: "The home of tandem paragliding and extreme sports."
  },
  {
    id: 2,
    location: "Uluwatu, Bali",
    image: "https://picsum.photos/seed/uluwatu/600/800",
    description: "Surfing and sunset cliffs."
  },
  {
    id: 3,
    location: "Queenstown, NZ",
    image: "https://picsum.photos/seed/nz/600/800",
    description: "The adventure capital of the world."
  }
];

const REVIEWS = [
  {
    id: 1,
    name: "Sarah Jenkins",
    avatar: "SJ",
    rating: 5,
    comment: "Zack made my first tandem jump so incredible! I felt safe and the video he edited was top-notch."
  },
  {
    id: 2,
    name: "Mark Thompson",
    avatar: "MT",
    rating: 5,
    comment: "Best travel guide and videographer. His energy is infectious!"
  },
  {
    id: 3,
    name: "Elena Rodriguez",
    avatar: "ER",
    rating: 5,
    comment: "The tandem video I got was worth every penny. Such a professional setup."
  }
];

const SOCIALS = [
  { name: "YouTube", icon: Youtube, url: "#", color: "text-red-500" },
  { name: "Instagram", icon: Instagram, url: "#", color: "text-pink-500" },
  { name: "Twitter", icon: Twitter, url: "#", color: "text-blue-400" },
  { name: "TikTok", icon: Globe, url: "#", color: "text-white" }
];

export default function App() {
  return (
    <div classname="min-h-screen bg-background text-foreground selection:bg-white/20">
      {/* Navbar */}
      <nav classname="fixed top-0 w-full z-50 glass border-b border-black/5">
        <div classname="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div classname="flex items-center gap-2">
            <div classname="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <span classname="text-primary-foreground font-bold text-xl">Z</span>
            </div>
            <span classname="font-display font-bold text-xl tracking-tighter text-foreground">NOMADIC ZACK</span>
          </div>
          
          <div classname="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
            <a href="#videos" classname="hover:text-primary transition-colors">Videos</a>
            <a href="#travels" classname="hover:text-primary transition-colors">Travels</a>
            <a href="#tandems" classname="hover:text-primary transition-colors">Tandems</a>
            <a href="#reviews" classname="hover:text-primary transition-colors">Reviews</a>
          </div>

          <button variant="outline" classname="rounded-full px-6 border-primary/20 hover:bg-primary hover:text-primary-foreground transition-all">
            Get in Touch
          </Button>
        </div>
      </nav>

      <main>
        {/* Hero Section */}
        <section classname="relative h-[85vh] flex items-center justify-center overflow-hidden pt-20">
          <div classname="absolute inset-0 z-0">
            <img src="https://images.unsplash.com/photo-1520690214124-2405c5217036?q=80&amp;w=2069&amp;auto=format&amp;fit=crop" alt="Skydiving Dubai" classname="w-full h-full object-cover" referrerpolicy="no-referrer"/>
            <div classname="absolute inset-0 bg-gradient-to-t from-background via-transparent to-black/20"/>
          </div>

          <div classname="relative z-10 max-w-5xl mx-auto px-6 text-center">
            <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" animate="{{" opacity:="" 1,="" y:="" 0="" }}="" transition="{{" duration:="" 0.8="" }}="" classname="glass p-12 rounded-[3rem] border-white/40 shadow-2xl">
              <badge variant="secondary" classname="mb-6 px-4 py-1 font-bold">
                ADVENTURER • VIDEOGRAPHER • TANDEM PILOT
              </Badge>
              <h1 classname="text-5xl md:text-7xl font-bold mb-8 leading-[1] tracking-tighter text-foreground">
                SOARING OVER <br/> <span classname="text-primary">THE PALM.</span>
              </h1>
              <p classname="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
                Capturing the world from above and sharing the thrill of the jump. 
                Experience the ultimate adrenaline rush with a view like no other.
              </p>
              <div classname="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button size="lg" classname="rounded-full px-8 bg-primary text-primary-foreground hover:opacity-90 w-full sm:w-auto shadow-lg shadow-primary/20">
                  Watch Latest Videos <play classname="ml-2 w-4 h-4 fill-current"/>
                </Button>
                <button size="lg" variant="outline" classname="rounded-full px-8 border-primary/20 hover:bg-primary/5 w-full sm:w-auto">
                  Book a Tandem
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Video Showcase */}
        <section id="videos" classname="py-32 px-6">
          <div classname="max-w-7xl mx-auto">
            <div classname="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
              <div>
                <h2 classname="text-4xl md:text-5xl font-bold mb-4">LATEST VIDEOS</h2>
                <p classname="text-muted-foreground max-w-md">
                  Fresh drops from my YouTube channel. High-octane adventures and cinematic travel logs.
                </p>
              </div>
              <button variant="link" classname="text-primary p-0 h-auto group">
                View All on YouTube <chevronright classname="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform"/>
              </Button>
            </div>

            <div classname="grid grid-cols-1 md:grid-cols-3 gap-8">
              {LATEST_VIDEOS.map((video, index) => (
                <motion.div key="{video.id}" initial="{{" opacity:="" 0,="" y:="" 20="" }}="" whileinview="{{" opacity:="" 1,="" y:="" 0="" }}="" transition="{{" delay:="" index="" *="" 0.1="" }}="" viewport="{{" once:="" true="" }}="">
                  <card classname="bg-white border-primary/5 overflow-hidden group cursor-pointer shadow-sm hover:shadow-xl transition-all duration-300">
                    <div classname="relative aspect-video overflow-hidden">
                      <img src="{video.thumbnail}" alt="{video.title}" classname="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerpolicy="no-referrer"/>
                      <div classname="absolute inset-0 bg-primary/10 group-hover:bg-transparent transition-colors"/>
                      <div classname="absolute bottom-3 right-3 bg-primary px-2 py-1 rounded text-[10px] font-bold text-primary-foreground">
                        10:45
                      </div>
                    </div>
                    <cardheader classname="p-5">
                      <cardtitle classname="text-lg leading-tight group-hover:text-primary transition-colors">
                        {video.title}
                      </CardTitle>
                      <carddescription classname="flex items-center gap-3 mt-2">
                        <span>{video.views} views</span>
                        <span classname="w-1 h-1 rounded-full bg-muted-foreground"/>
                        <span>{video.date}</span>
                      </CardDescription>
                    </CardHeader>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Travel Log */}
        <section id="travels" classname="py-32 bg-secondary/10">
          <div classname="max-w-7xl mx-auto px-6">
            <div classname="text-center mb-20">
              <h2 classname="text-4xl md:text-5xl font-bold mb-4">TRAVEL LOG</h2>
              <p classname="text-muted-foreground max-w-xl mx-auto">
                Mapping my journey across the globe. From the peaks of Switzerland to the beaches of Bali.
              </p>
            </div>

            <div classname="grid grid-cols-1 md:grid-cols-3 gap-6">
              {TRAVELS.map((travel, index) => (
                <motion.div key="{travel.id}" classname="relative group aspect-[3/4] rounded-3xl overflow-hidden shadow-lg" initial="{{" opacity:="" 0,="" scale:="" 0.95="" }}="" whileinview="{{" opacity:="" 1,="" scale:="" 1="" }}="" transition="{{" delay:="" index="" *="" 0.1="" }}="" viewport="{{" once:="" true="" }}="">
                  <img src="{travel.image}" alt="{travel.location}" classname="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" referrerpolicy="no-referrer"/>
                  <div classname="absolute inset-0 bg-gradient-to-t from-primary/90 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity"/>
                  <div classname="absolute bottom-0 left-0 p-8 w-full">
                    <div classname="flex items-center gap-2 mb-2">
                      <mappin classname="w-4 h-4 text-white"/>
                      <span classname="text-xs font-bold uppercase tracking-widest text-white/80">Location</span>
                    </div>
                    <h3 classname="text-2xl font-bold mb-2 text-white">{travel.location}</h3>
                    <p classname="text-sm text-white/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      {travel.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Tandem Hub */}
        <section id="tandems" classname="py-32 px-6 bg-white">
          <div classname="max-w-7xl mx-auto">
            <div classname="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 classname="text-4xl md:text-5xl font-bold mb-6">TANDEM HUB</h2>
                <p classname="text-lg text-muted-foreground mb-8 leading-relaxed">
                  Did you jump with me? This is your one-stop shop to grab your high-definition 
                  videos, photos, and leave a tip if you enjoyed the experience.
                </p>
                
                <div classname="space-y-6">
                  <div classname="flex gap-4">
                    <div classname="w-12 h-12 rounded-2xl bg-primary/5 flex items-center justify-center shrink-0">
                      <video classname="w-6 h-6 text-primary"/>
                    </div>
                    <div>
                      <h4 classname="font-bold mb-1">Get Your Videos</h4>
                      <p classname="text-sm text-muted-foreground">Enter your jump ID to download your 4K footage and photos.</p>
                    </div>
                  </div>
                  <div classname="flex gap-4">
                    <div classname="w-12 h-12 rounded-2xl bg-secondary/20 flex items-center justify-center shrink-0">
                      <dollarsign classname="w-6 h-6 text-foreground"/>
                    </div>
                    <div>
                      <h4 classname="font-bold mb-1">Leave a Tip</h4>
                      <p classname="text-sm text-muted-foreground">Support my travels and future content. Every bit helps!</p>
                    </div>
                  </div>
                </div>

                <div classname="mt-10 flex gap-4">
                  <button classname="rounded-full px-8 bg-primary text-primary-foreground hover:opacity-90 shadow-lg shadow-primary/20">
                    Find My Video
                  </Button>
                  <button variant="outline" classname="rounded-full px-8 border-primary/20 hover:bg-primary/5">
                    Leave a Tip
                  </Button>
                </div>
              </div>

              <div classname="relative">
                <div classname="absolute -inset-4 bg-gradient-to-tr from-primary/10 to-secondary/10 rounded-[2rem] blur-2xl"/>
                <card classname="relative bg-white border-primary/10 rounded-[2rem] overflow-hidden shadow-xl">
                  <cardheader classname="p-8 pb-0">
                    <cardtitle>Recent Tandems</CardTitle>
                    <carddescription>Check out some of the latest jumps</CardDescription>
                  </CardHeader>
                  <cardcontent classname="p-8">
                    <scrollarea classname="h-[300px] pr-4">
                      <div classname="space-y-6">
                        {[1, 2, 3, 4, 5].map((i) => (
                          <div key="{i}" classname="flex items-center justify-between group">
                            <div classname="flex items-center gap-4">
                              <avatar classname="h-10 w-10 border border-primary/10">
                                <avatarimage src="{`https://i.pravatar.cc/150?u=${i}`}"/>
                                <avatarfallback>U</AvatarFallback>
                              </Avatar>
                              <div>
                                <p classname="text-sm font-medium">Jump #{1024 + i}</p>
                                <p classname="text-xs text-muted-foreground">24th Oct, 2023 • Dubai</p>
                              </div>
                            </div>
                            <button size="sm" variant="ghost" classname="opacity-0 group-hover:opacity-100 transition-opacity text-primary">
                              Preview
                            </Button>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Socials & Reviews */}
        <section id="reviews" classname="py-32 bg-accent/5">
          <div classname="max-w-7xl mx-auto px-6">
            <div classname="grid grid-cols-1 lg:grid-cols-3 gap-16">
              {/* Social Links */}
              <div classname="lg:col-span-1">
                <h2 classname="text-3xl font-bold mb-8">STAY CONNECTED</h2>
                <div classname="grid grid-cols-2 gap-4">
                  {SOCIALS.map((social) => (
                    <a key="{social.name}" href="{social.url}" classname="flex flex-col items-center justify-center p-6 rounded-3xl bg-white border border-primary/5 shadow-sm hover:border-primary/20 hover:shadow-md transition-all group">
                      <social.icon classname="{`w-8" h-8="" mb-3="" ${social.color}="" transition-transform="" group-hover:scale-110`}=""/>
                      <span classname="text-xs font-bold uppercase tracking-widest text-foreground">{social.name}</span>
                    </a>
                  ))}
                </div>
                <div classname="mt-8 p-6 rounded-3xl bg-white border border-primary/5 shadow-sm">
                  <h4 classname="font-bold mb-2">Newsletter</h4>
                  <p classname="text-sm text-muted-foreground mb-4">Get travel updates and exclusive content.</p>
                  <div classname="flex gap-2">
                    <input type="email" placeholder="Email address" classname="bg-muted border border-border rounded-full px-4 py-2 text-sm w-full focus:outline-none focus:border-primary/40"/>
                    <button size="icon" classname="rounded-full shrink-0 bg-primary text-primary-foreground hover:opacity-90">
                      <chevronright classname="w-4 h-4"/>
                    </Button>
                  </div>
                </div>
              </div>

              {/* Reviews */}
              <div classname="lg:col-span-2">
                <div classname="flex items-center justify-between mb-8">
                  <h2 classname="text-3xl font-bold">WHAT PEOPLE SAY</h2>
                  <div classname="flex items-center gap-1 text-secondary">
                    <star classname="w-4 h-4 fill-current"/>
                    <span classname="font-bold text-foreground">4.9/5</span>
                    <span classname="text-muted-foreground text-sm font-normal ml-1">(250+ reviews)</span>
                  </div>
                </div>

                <div classname="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {REVIEWS.map((review) => (
                    <card key="{review.id}" classname="bg-white border-primary/5 p-8 rounded-3xl shadow-sm">
                      <div classname="flex items-center gap-4 mb-6">
                        <avatar classname="h-12 w-12 border border-primary/10">
                          <avatarfallback classname="bg-primary/10 text-primary">{review.avatar}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 classname="font-bold">{review.name}</h4>
                          <div classname="flex gap-0.5">
                            {[...Array(review.rating)].map((_, i) => (
                              <star key="{i}" classname="w-3 h-3 fill-secondary text-secondary"/>
                            ))}
                          </div>
                        </div>
                      </div>
                      <p classname="text-muted-foreground italic leading-relaxed">
                        "{review.comment}"
                      </p>
                    </Card>
                  ))}
                </div>
                
                <div classname="mt-8 text-center">
                  <button variant="outline" classname="rounded-full px-8 border-primary/20 hover:bg-primary/5">
                    Leave a Review <messagesquare classname="ml-2 w-4 h-4"/>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer classname="py-20 border-t border-primary/10 bg-white">
        <div classname="max-w-7xl mx-auto px-6">
          <div classname="flex flex-col md:flex-row justify-between items-center gap-10">
            <div classname="flex flex-col items-center md:items-start gap-4">
              <div classname="flex items-center gap-2">
                <div classname="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                  <span classname="text-primary-foreground font-bold text-lg">Z</span>
                </div>
                <span classname="font-display font-bold text-lg tracking-tighter text-foreground">NOMADIC ZACK</span>
              </div>
              <p classname="text-sm text-muted-foreground text-center md:text-left">
                © 2024 Nomadic Zack. All rights reserved. <br/>
                Capturing the thrill, one jump at a time.
              </p>
            </div>

            <div classname="flex gap-8 text-sm font-medium text-muted-foreground">
              <a href="#" classname="hover:text-primary transition-colors">Privacy</a>
              <a href="#" classname="hover:text-primary transition-colors">Terms</a>
              <a href="#" classname="hover:text-primary transition-colors">Contact</a>
            </div>

            <div classname="flex gap-4">
              <button size="icon" variant="ghost" classname="rounded-full hover:bg-primary/10 text-primary">
                <youtube classname="w-5 h-5"/>
              </Button>
              <button size="icon" variant="ghost" classname="rounded-full hover:bg-primary/10 text-primary">
                <instagram classname="w-5 h-5"/>
              </Button>
              <button size="icon" variant="ghost" classname="rounded-full hover:bg-primary/10 text-primary">
                <twitter classname="w-5 h-5"/>
              </Button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
