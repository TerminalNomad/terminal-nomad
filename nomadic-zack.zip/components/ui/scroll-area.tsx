"use client"

import * as React from "react"
import { ScrollArea as ScrollAreaPrimitive } from "@base-ui/react/scroll-area"

import { cn } from "@/lib/utils"

function ScrollArea({
  className,
  children,
  ...props
}: ScrollAreaPrimitive.Root.Props) {
  return (
    <scrollareaprimitive.root data-slot="scroll-area" classname="{cn(&#34;relative&#34;," classname)}="" {...props}="">
      <scrollareaprimitive.viewport data-slot="scroll-area-viewport" classname="size-full rounded-[inherit] transition-[color,box-shadow] outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-1">
        {children}
      </ScrollAreaPrimitive.Viewport>
      <scrollbar/>
      <scrollareaprimitive.corner/>
    </ScrollAreaPrimitive.Root>
  )
}

function ScrollBar({
  className,
  orientation = "vertical",
  ...props
}: ScrollAreaPrimitive.Scrollbar.Props) {
  return (
    <scrollareaprimitive.scrollbar data-slot="scroll-area-scrollbar" data-orientation="{orientation}" orientation="{orientation}" classname="{cn(" "flex="" touch-none="" p-px="" transition-colors="" select-none="" data-horizontal:h-2.5="" data-horizontal:flex-col="" data-horizontal:border-t="" data-horizontal:border-t-transparent="" data-vertical:h-full="" data-vertical:w-2.5="" data-vertical:border-l="" data-vertical:border-l-transparent",="" classname="" )}="" {...props}="">
      <scrollareaprimitive.thumb data-slot="scroll-area-thumb" classname="relative flex-1 rounded-full bg-border"/>
    </ScrollAreaPrimitive.Scrollbar>
  )
}

export { ScrollArea, ScrollBar }
