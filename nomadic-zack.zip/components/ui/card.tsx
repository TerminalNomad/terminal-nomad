import * as React from "react"

import { cn } from "@/lib/utils"

function Card({
  className,
  size = "default",
  ...props
}: React.ComponentProps<"div"> & { size?: "default" | "sm" }) {
  return (
    <div data-slot="card" data-size="{size}" classname="{cn(" "group="" card="" flex="" flex-col="" gap-4="" overflow-hidden="" rounded-xl="" bg-card="" py-4="" text-sm="" text-card-foreground="" ring-1="" ring-foreground="" 10="" has-data-[slot="card-footer]:pb-0" has-[="">img:first-child]:pt-0 data-[size=sm]:gap-3 data-[size=sm]:py-3 data-[size=sm]:has-data-[slot=card-footer]:pb-0 *:[img:first-child]:rounded-t-xl *:[img:last-child]:rounded-b-xl",
        className
      )}
      {...props}
    />
  )
}

function CardHeader({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div data-slot="card-header" classname="{cn(" "group="" card-header="" @container="" card-header="" grid="" auto-rows-min="" items-start="" gap-1="" rounded-t-xl="" px-4="" group-data-[size="sm]/card:px-3" has-data-[slot="card-action]:grid-cols-[1fr_auto]" has-data-[slot="card-description]:grid-rows-[auto_auto]" [.border-b]:pb-4="" group-data-[size="sm]/card:[.border-b]:pb-3&#34;," classname="" )}="" {...props}=""/>
  )
}

function CardTitle({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div data-slot="card-title" classname="{cn(" "font-heading="" text-base="" leading-snug="" font-medium="" group-data-[size="sm]/card:text-sm&#34;," classname="" )}="" {...props}=""/>
  )
}

function CardDescription({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div data-slot="card-description" classname="{cn(&#34;text-sm" text-muted-foreground",="" classname)}="" {...props}=""/>
  )
}

function CardAction({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div data-slot="card-action" classname="{cn(" "col-start-2="" row-span-2="" row-start-1="" self-start="" justify-self-end",="" classname="" )}="" {...props}=""/>
  )
}

function CardContent({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div data-slot="card-content" classname="{cn(&#34;px-4" group-data-[size="sm]/card:px-3&#34;," classname)}="" {...props}=""/>
  )
}

function CardFooter({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div data-slot="card-footer" classname="{cn(" "flex="" items-center="" rounded-b-xl="" border-t="" bg-muted="" 50="" p-4="" group-data-[size="sm]/card:p-3&#34;," classname="" )}="" {...props}=""/>
  )
}

export {
  Card,
  CardHeader,
  CardFooter,
  CardTitle,
  CardAction,
  CardDescription,
  CardContent,
}
