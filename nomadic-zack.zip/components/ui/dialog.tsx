"use client"

import * as React from "react"
import { Dialog as DialogPrimitive } from "@base-ui/react/dialog"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { XIcon } from "lucide-react"

function Dialog({ ...props }: DialogPrimitive.Root.Props) {
  return <dialogprimitive.root data-slot="dialog" {...props}=""/>
}

function DialogTrigger({ ...props }: DialogPrimitive.Trigger.Props) {
  return <dialogprimitive.trigger data-slot="dialog-trigger" {...props}=""/>
}

function DialogPortal({ ...props }: DialogPrimitive.Portal.Props) {
  return <dialogprimitive.portal data-slot="dialog-portal" {...props}=""/>
}

function DialogClose({ ...props }: DialogPrimitive.Close.Props) {
  return <dialogprimitive.close data-slot="dialog-close" {...props}=""/>
}

function DialogOverlay({
  className,
  ...props
}: DialogPrimitive.Backdrop.Props) {
  return (
    <dialogprimitive.backdrop data-slot="dialog-overlay" classname="{cn(" "fixed="" inset-0="" isolate="" z-50="" bg-black="" 10="" duration-100="" supports-backdrop-filter:backdrop-blur-xs="" data-open:animate-in="" data-open:fade-in-0="" data-closed:animate-out="" data-closed:fade-out-0",="" classname="" )}="" {...props}=""/>
  )
}

function DialogContent({
  className,
  children,
  showCloseButton = true,
  ...props
}: DialogPrimitive.Popup.Props & {
  showCloseButton?: boolean
}) {
  return (
    <dialogportal>
      <dialogoverlay/>
      <dialogprimitive.popup data-slot="dialog-content" classname="{cn(" "fixed="" top-1="" 2="" left-1="" 2="" z-50="" grid="" w-full="" max-w-[calc(100%-2rem)]="" -translate-x-1="" 2="" -translate-y-1="" 2="" gap-4="" rounded-xl="" bg-popover="" p-4="" text-sm="" text-popover-foreground="" ring-1="" ring-foreground="" 10="" duration-100="" outline-none="" sm:max-w-sm="" data-open:animate-in="" data-open:fade-in-0="" data-open:zoom-in-95="" data-closed:animate-out="" data-closed:fade-out-0="" data-closed:zoom-out-95",="" classname="" )}="" {...props}="">
        {children}
        {showCloseButton && (
          <dialogprimitive.close data-slot="dialog-close" render="{" <button="" variant="ghost" classname="absolute top-2 right-2" size="icon-sm"/>
            }
          >
            <xicon/>
            <span classname="sr-only">Close</span>
          </DialogPrimitive.Close>
        )}
      </DialogPrimitive.Popup>
    </DialogPortal>
  )
}

function DialogHeader({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div data-slot="dialog-header" classname="{cn(&#34;flex" flex-col="" gap-2",="" classname)}="" {...props}=""/>
  )
}

function DialogFooter({
  className,
  showCloseButton = false,
  children,
  ...props
}: React.ComponentProps<"div"> & {
  showCloseButton?: boolean
}) {
  return (
    <div data-slot="dialog-footer" classname="{cn(" "-mx-4="" -mb-4="" flex="" flex-col-reverse="" gap-2="" rounded-b-xl="" border-t="" bg-muted="" 50="" p-4="" sm:flex-row="" sm:justify-end",="" classname="" )}="" {...props}="">
      {children}
      {showCloseButton && (
        <dialogprimitive.close render="{&lt;Button" variant="outline"/>}>
          Close
        </DialogPrimitive.Close>
      )}
    </div>
  )
}

function DialogTitle({ className, ...props }: DialogPrimitive.Title.Props) {
  return (
    <dialogprimitive.title data-slot="dialog-title" classname="{cn(" "font-heading="" text-base="" leading-none="" font-medium",="" classname="" )}="" {...props}=""/>
  )
}

function DialogDescription({
  className,
  ...props
}: DialogPrimitive.Description.Props) {
  return (
    <dialogprimitive.description data-slot="dialog-description" classname="{cn(" "text-sm="" text-muted-foreground="" *:[a]:underline="" *:[a]:underline-offset-3="" *:[a]:hover:text-foreground",="" classname="" )}="" {...props}=""/>
  )
}

export {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogOverlay,
  DialogPortal,
  DialogTitle,
  DialogTrigger,
}
